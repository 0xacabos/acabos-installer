#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

# AI_SUBSTRATE -- Install Python ML venv (via uv), llama.cpp, AI tools, container quadlets.
# Phase 1: Install uv + create /opt/ai-venv
# Phase 2: Install PyTorch from CUDA wheel index
# Phase 3: Install ML packages from requirements file
# Phase 4: Install ML packages from requirements file
# Phase 5: Clone + build llama.cpp with CUDA
# Phase 6: Install AI utility scripts
# Phase 7: Install container quadlets (9 services + pod)
# Phase 8: Install Jupyter configuration
# Re-entry probe: lib/probes.sh probe_ai()
run_ai() {
  log "=== AI_SUBSTRATE ==="

  local target="/mnt/install"

  log "Phase 1: Installing system AI packages..."
  local pkg_file="${INSTALLER_DIR}/config/ai-system-packages.list"
  [[ -f "$pkg_file" ]] || fail "AI system package list not found: ${pkg_file}"
  local sys_pkgs
  sys_pkgs=$(grep -v '^\s*#' "$pkg_file" | grep -v '^\s*$' | tr '\n' ' ' | sed 's/[[:space:]]*$//')
  [[ -n "$sys_pkgs" ]] || fail "AI system package list is empty"

  chroot_mount "$target"
  run_timeout "$LONG_TIMEOUT" chroot "$target" apt-get install -y $sys_pkgs \
    || { chroot_umount "$target"; fail "AI system package installation failed"; }
  chroot_umount "$target"
  log "Phase 1 complete: System AI packages installed."

  log "Phase 2: Installing uv and creating Python venv..."
  chroot_mount "$target"

  run_timeout "$MEDIUM_TIMEOUT" chroot "$target" bash -c \
    'curl -fsSL https://astral.sh/uv/install.sh | env CARGO_HOME=/opt/uv UV_INSTALL_DIR=/opt/uv sh' \
    || { chroot_umount "$target"; fail "uv installation failed"; }

  local uv_bin="${target}/opt/uv/uv"
  [[ -x "$uv_bin" ]] || { chroot_umount "$target"; fail "uv binary not found at ${uv_bin}"; }
  log "  uv installed: $("${uv_bin}" --version 2>/dev/null || echo 'unknown')"

  run_timeout "$MEDIUM_TIMEOUT" chroot "$target" /opt/uv/uv venv --python 3 /opt/ai-venv \
    || { chroot_umount "$target"; fail "Failed to create /opt/ai-venv"; }

  [[ -f "${target}/opt/ai-venv/bin/python" ]] || { chroot_umount "$target"; fail "ai-venv python not found"; }
  local py_ver
  py_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" /opt/ai-venv/bin/python --version 2>/dev/null || echo "unknown")
  log "  Python venv created: ${py_ver}"

  chroot_umount "$target"
  log "Phase 2 complete: uv + Python venv ready."

  log "Phase 3: Installing PyTorch from CUDA wheel index..."
  chroot_mount "$target"

  run_timeout "$BUILD_TIMEOUT" chroot "$target" /opt/uv/uv pip install \
    --python /opt/ai-venv/bin/python \
    torch torchvision torchaudio \
    --index-url https://download.pytorch.org/whl/cu124 \
    || { chroot_umount "$target"; fail "PyTorch installation failed"; }

  local torch_ver
  torch_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" /opt/ai-venv/bin/python -c \
    'import torch; print(torch.__version__)' 2>/dev/null || echo "unknown")
  log "  PyTorch installed: ${torch_ver}"

  chroot_umount "$target"
  log "Phase 3 complete: PyTorch installed."

  log "Phase 4: Installing ML packages from requirements..."
  local req_file="${INSTALLER_DIR}/config/ai-venv-requirements.txt"
  [[ -f "$req_file" ]] || fail "AI venv requirements not found: ${req_file}"

  cp "$req_file" "${target}/tmp/ai-requirements.txt"
  chroot_mount "$target"

  run_timeout "$BUILD_TIMEOUT" chroot "$target" /opt/uv/uv pip install \
    --python /opt/ai-venv/bin/python \
    -r /tmp/ai-requirements.txt \
    || { chroot_umount "$target"; fail "ML packages installation failed"; }

  rm -f "${target}/tmp/ai-requirements.txt"
  log "  ML packages installed."

  log "  Creating ai-python and ai-pip symlinks..."
  ln -sf /opt/ai-venv/bin/python "${target}/usr/local/bin/ai-python"
  ln -sf /opt/ai-venv/bin/pip "${target}/usr/local/bin/ai-pip"
  log "  Symlinks created."

  chroot_umount "$target"
  log "Phase 4 complete: ML packages installed."

  log "Phase 5: Building llama.cpp with CUDA..."
  chroot_mount "$target"

  run_timeout "$LONG_TIMEOUT" chroot "$target" bash -c \
    'git clone --depth 1 https://github.com/ggerganov/llama.cpp.git /opt/llama-cpp' \
    || { chroot_umount "$target"; fail "Failed to clone llama.cpp"; }

  run_timeout "$BUILD_TIMEOUT" chroot "$target" bash -c \
    'cd /opt/llama-cpp && cmake -B build -DGGML_CUDA=ON -DCMAKE_BUILD_TYPE=Release && cmake --build build --config Release -j"$(nproc)"' \
    || { chroot_umount "$target"; fail "llama.cpp build failed"; }

  [[ -x "${target}/opt/llama-cpp/build/bin/llama-cli" ]] || { chroot_umount "$target"; fail "llama.cpp llama-cli binary not found"; }
  [[ -x "${target}/opt/llama-cpp/build/bin/llama-quantize" ]] || warn "llama.cpp llama-quantize binary not found"

  ln -sf /opt/llama-cpp/build/bin/llama-cli "${target}/usr/local/bin/llama" \
    || warn "Failed to create llama symlink"
  ln -sf /opt/llama-cpp/build/bin/llama-quantize "${target}/usr/local/bin/llama-quantize" \
    || warn "Failed to create llama-quantize symlink"

  run_timeout "$LONG_TIMEOUT" chroot "$target" bash -c \
    'git clone --depth 1 https://github.com/NVIDIA/cuda-samples.git /opt/cuda-samples' 2>/dev/null \
    || warn "Failed to clone optional CUDA samples"

  chroot_umount "$target"
  log "Phase 5 complete: llama.cpp built and installed."

  log "Phase 6: Installing AI utility scripts..."
  mkdir -p "${target}/usr/local/bin"

  cat > "${target}/usr/local/bin/model-manager" << 'MODEL_MGR'
#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
echo "ACABOS Model Manager"
echo "Usage: model-manager [download|list|serve] <model>"
echo "  download <model>  - Download model from HuggingFace"
echo "  list              - List cached models"
echo "  serve <model>     - Serve model via mistral.rs"
echo ""
if [[ $# -eq 0 ]]; then
    exit 0
fi
CMD="$1"
shift
case "$CMD" in
    download)
        [[ $# -ge 1 ]] || { echo "Usage: model-manager download <model-name>"; exit 1; }
        /opt/ai-venv/bin/python - "$1" <<'PY'
import os
import sys
from huggingface_hub import snapshot_download

model = sys.argv[1]
target = os.path.join('/opt/acab/models', model)
snapshot_download(repo_id=model, local_dir=target)
PY
        ;;
    list)
        ls -la /opt/acab/models/ 2>/dev/null || echo "No models found."
        ;;
    serve)
        [[ $# -ge 1 ]] || { echo "Usage: model-manager serve <model-path>"; exit 1; }
        /opt/acab/bin/mistral-rs serve --port 8012 "$1"
        ;;
    *)
        echo "Unknown command: $CMD"
        exit 1
        ;;
esac
MODEL_MGR
  chmod 755 "${target}/usr/local/bin/model-manager"

  cat > "${target}/usr/local/bin/gpu-benchmark" << 'GPU_BENCH'
#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
echo "=== ACABOS GPU Benchmark ==="
echo ""
echo "GPU Information:"
nvidia-smi --query-gpu=name,driver_version,memory.total,temperature.gpu --format=csv,noheader
echo ""
echo "CUDA Information:"
/opt/ai-venv/bin/python -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}'); print(f'CUDA device: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else \"N/A\"}')" 2>/dev/null || echo "CUDA check failed"
echo ""
echo "Running PyTorch matrix multiply benchmark..."
/opt/ai-venv/bin/python -c "
import torch
import time
if not torch.cuda.is_available():
    print('CUDA not available, skipping GPU benchmark')
    exit(0)
device = torch.device('cuda')
sizes = [1024, 2048, 4096]
for s in sizes:
    a = torch.randn(s, s, device=device)
    b = torch.randn(s, s, device=device)
    torch.cuda.synchronize()
    start = time.time()
    for _ in range(10):
        c = torch.mm(a, b)
    torch.cuda.synchronize()
    elapsed = time.time() - start
    print(f'  {s}x{s} matrix multiply x10: {elapsed:.4f}s ({10*2*s**3/elapsed/1e12:.2f} TFLOPS)')
" 2>/dev/null || echo "Benchmark failed"
echo ""
echo "Benchmark complete."
GPU_BENCH
  chmod 755 "${target}/usr/local/bin/gpu-benchmark"

  cat > "${target}/usr/local/bin/ai-services" << 'AI_SVC'
#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
ACTION="${1:-status}"
SERVICES=(ollama ollama-webui ai-toolbox stable-diffusion comfyui text-generation-webui localai whisper-asr qdrant)
case "$ACTION" in
    start|stop|restart|status|logs)
        for svc in "${SERVICES[@]}"; do
            systemctl "$ACTION" "${svc}.service" 2>/dev/null || true
        done
        ;;
    pull)
        for svc in "${SERVICES[@]}"; do
            unit_path="/etc/containers/systemd/${svc}.container"
            [[ -f "$unit_path" ]] || continue
            image=$(grep '^Image=' "$unit_path" | cut -d= -f2)
            [[ -n "$image" ]] && podman pull "$image" 2>/dev/null || true
        done
        ;;
    *)
        echo "Usage: ai-services {start|stop|restart|status|logs|pull}"
        exit 1
        ;;
esac
AI_SVC
  chmod 755 "${target}/usr/local/bin/ai-services"

  cat > "${target}/usr/local/bin/ai-shell" << 'AI_SHELL'
#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
container="${1:-ai-toolbox}"
exec podman exec -it "$container" /bin/bash
AI_SHELL
  chmod 755 "${target}/usr/local/bin/ai-shell"

  cat > "${target}/usr/local/bin/ai-stack" << 'AI_STACK'
#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
cmd="${1:-status}"
case "$cmd" in
  up)
    systemctl start ollama.service ollama-webui.service ai-toolbox.service stable-diffusion.service comfyui.service text-generation-webui.service localai.service whisper-asr.service qdrant.service
    ;;
  down)
    systemctl stop ollama.service ollama-webui.service ai-toolbox.service stable-diffusion.service comfyui.service text-generation-webui.service localai.service whisper-asr.service qdrant.service
    ;;
  status)
    systemctl status ollama.service ollama-webui.service ai-toolbox.service stable-diffusion.service comfyui.service text-generation-webui.service localai.service whisper-asr.service qdrant.service --no-pager
    ;;
  *)
    echo "Usage: ai-stack {up|down|status}"
    exit 1
    ;;
esac
AI_STACK
  chmod 755 "${target}/usr/local/bin/ai-stack"

  cat > "${target}/usr/local/bin/test-nvidia-container" << 'TEST_GPU'
#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
podman run --rm --device nvidia.com/gpu=all docker.io/nvidia/cuda:12.4.1-base-ubuntu22.04 nvidia-smi
TEST_GPU
  chmod 755 "${target}/usr/local/bin/test-nvidia-container"

  log "Phase 6 complete: AI utility scripts installed."

  log "Phase 7: Installing container quadlets..."
  local quadlet_dir="${target}/etc/containers/systemd"
  mkdir -p "$quadlet_dir"

  for quadlet in "${INSTALLER_DIR}/config/quadlets/"*; do
    [[ -f "$quadlet" ]] || continue
    cp "$quadlet" "${quadlet_dir}/$(basename "$quadlet")"
    log "  Installed quadlet: $(basename "$quadlet")"
  done

  chroot_mount "$target"
  run_timeout "$MEDIUM_TIMEOUT" chroot "$target" systemctl daemon-reload 2>/dev/null \
    || warn "systemctl daemon-reload failed in chroot"
  chroot_umount "$target"
  log "Phase 7 complete: Container quadlets installed."

  log "Phase 8: Installing Jupyter configuration..."
  mkdir -p "${target}/etc/jupyter"
  cp "${INSTALLER_DIR}/config/jupyter/jupyter_server_config.py" "${target}/etc/jupyter/jupyter_server_config.py"
  log "Phase 8 complete: Jupyter configured."

  log "Validating AI substrate..."
  [[ -f "${target}/opt/ai-venv/bin/python" ]] || fail "ai-venv python not found"
  [[ -f "${target}/usr/local/bin/ai-python" ]] || fail "ai-python symlink not found"
  [[ -f "${target}/opt/llama-cpp/build/bin/llama-cli" ]] || fail "llama.cpp binary not found"
  [[ -f "${target}/etc/containers/systemd/ollama.container" ]] || fail "ollama quadlet not found"
  [[ -f "${target}/etc/jupyter/jupyter_server_config.py" ]] || fail "jupyter config not found"

  log "AI_SUBSTRATE complete."
  return 0
}
