# Architecture

## System Design

ACABOS is a Bash state machine that runs from a Debian Trixie live session and provisions a baseline AI workstation in 13 ordered, resumable stages.

## Stage Flow

```
PREFLIGHT
  -> INPUT
  -> DISK_SAFETY
  -> ZFS_CREATE
  -> BASE_INSTALL
  -> BOOT_CHAIN
  -> NVIDIA_BRINGUP
  -> PODMAN_SUBSTRATE
  -> DESKTOP_SUBSTRATE
  -> AI_SUBSTRATE
  -> INFERENCE_SUBSTRATE
  -> VALIDATION
  -> FINALIZE
```

State is persisted in `state/install-state.json` and includes:

- `state_version`
- `install_id`
- `current_stage`
- `pool_name`
- `target_disk`
- `hostname`
- `username`
- per-stage status/timestamps

## Storage Layout

Installer creates pool `ACABROOT-XXXX` with `ashift=12`, encryption enabled, and bootfs set to `ROOT/acabos`.

Dataset topology includes:

- `${pool}/ROOT/acabos` mounted at `/`
- `${pool}/opt/acab/*` for ACAB runtime assets
- `${pool}/opt/ai-venv` mounted at `/opt/ai-venv`
- `${pool}/opt/llama-cpp` mounted at `/opt/llama-cpp`
- `${pool}/var/lib/containers`, `${pool}/var/log`, `${pool}/var/cache`, `${pool}/var/tmp`
- `${pool}/home`
- `${pool}/swap` zvol (size ~= RAM)

Key constraints:

- no `org.zfsbootmenu:keysource`
- keyfile is temporary and shredded
- encryption transitions to `keylocation=prompt`

## Boot Chain

BOOT_CHAIN installs and validates:

- dracut config (`config/dracut.conf.d/zfs.conf`)
- ZFSBootMenu config (`config/zfsbootmenu-config.yaml`)
- `/etc/default/zfs`
- ZBM dracut conf (`/etc/zfsbootmenu/dracut.conf.d/10-acabos.conf`)
- NVIDIA modprobe and udev configs
- sysctl performance tuning

Kernel cmdline includes NVIDIA DRM/KMS options. EFI artifacts are validated and an EFI boot entry registration is attempted as best-effort if `efibootmgr` is available.

## Package Strategy

APT trust and pinning are explicit:

- Debian trixie base
- trixie-backports cohort pinning
- NVIDIA CUDA repo pinning
- NVIDIA Container Toolkit repo pinning
- cuDNN local repo during inference stage

BASE_INSTALL installs boot/runtime essentials via mmdebstrap include list, including ZFS, dracut, ZBM, Python toolchain basics, and ZED.

## NVIDIA + Runtime Substrates

NVIDIA_BRINGUP installs:

- `nvidia-kernel-open-dkms`
- `nvidia-driver`
- `cuda-toolkit-13-2` (+ CUDA libs/dev/CLI/NVML packages)
- `nvidia-container-toolkit`
- `nvidia-persistenced`

Validation is two-phase:

- build validation (DKMS/module files)
- runtime validation (strict on physical hardware, warning-only in virtual contexts)

PODMAN_SUBSTRATE installs Podman/buildah/skopeo/netavark stack and writes container configs plus CDI spec.

## Desktop + AI Substrates

DESKTOP_SUBSTRATE installs Sway/Waybar and writes user defaults into `/etc/skel` (not direct `/home/$user` writes) so FINALIZE user creation inherits configs safely.

AI_SUBSTRATE installs:

- system AI packages
- `uv` + `/opt/ai-venv`
- PyTorch CUDA wheels (`cu124` index)
- ML requirements bundle
- llama.cpp built with CMake + `GGML_CUDA=ON` in `/opt/llama-cpp`
- AI helper scripts
- quadlets in `/etc/containers/systemd`
- Jupyter server config

## Inference Substrate

INFERENCE_SUBSTRATE performs:

- cuDNN local repo install + SHA256 verification
- Rust install via rustup
- Rust minimum version gate (`RUST_MIN_VERSION`)
- `cargo install mistralrs-cli@<version>` with configured features
- installation to `/opt/acab/bin/mistral-rs`

## Validation (acabos-doctor)

Doctor runs 22 checks across 7 domains:

- Storage
- Boot
- Graphics
- Runtime
- Desktop
- System
- Manifest

Checks are dependency-aware and use skip semantics to avoid cascade noise.

## Finalization

FINALIZE performs:

- manifest generation via `config/manifest-template.jq`
- user creation + forced password reset
- root account lock
- linger enable for user
- first-boot service installation
- MOTD and `/etc/issue` deployment
- log and manifest copy into target
- pool export
