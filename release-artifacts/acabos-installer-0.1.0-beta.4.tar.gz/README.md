# ACABOS Installer

Bash-based, stateful, resumable installer that produces a **baseline AI development workstation** running Debian Trixie with:

- Encrypted ZFS root (`aes-256-gcm`, passphrase unlock)
- ZFSBootMenu boot loader
- NVIDIA GPU acceleration (OpenDKMS, CUDA 13.2, cuDNN 9.19.0)
- Podman container runtime
- Local inference via mistral.rs (built from source with CUDA/cuDNN/flash-attn)

## Target Hardware

| Component | Requirement |
|-----------|-------------|
| CPU | x86_64 |
| GPU | NVIDIA RTX 4070 (Turing or later) |
| RAM | 32 GB |
| Storage | Single NVMe |
| Boot | UEFI |

## Prerequisites

The installer runs from a **Debian Trixie live USB session** with root privileges. The live environment must have:

- `zpool`, `zfs`, `mmdebstrap`, `dracut`, `hexdump`, `curl`, `sgdisk`, `wipefs`, `lsinitrd`, `jq`, `dosfsck`, `sha256sum`, `timeout`, `stat`
- Network connectivity (required for package downloads, keyring fetch, cuDNN download, and `cargo install`)
- Debian archive keyring at `/usr/share/keyrings/debian-archive-keyring.gpg`

## Quick Start

```bash
# Boot into Debian Trixie live USB, then:
sudo ./acabos-install

# If resuming an interrupted install:
sudo ./acabos-install --resume

# Skip GPU runtime validation (VMs, CI):
sudo ./acabos-install --skip-gpu-validation

# Drop to recovery shell before starting:
sudo ./acabos-install --shell

# Non-interactive FINALIZE password injection:
sudo ACABOS_USER_PASSWORD='choose-a-strong-password' ./acabos-install --resume
```

Prompting behavior:
- If `gum` is available and running in an interactive TTY, prompts use `gum`.
- Otherwise prompts fall back to standard shell input.
- Disk selection uses `fzf` with a live partition preview when interactive.

## Installation Stages

The installer progresses through 13 ordered, resumable stages:

```
PREFLIGHT → INPUT → DISK_SAFETY → ZFS_CREATE → BASE_INSTALL
→ BOOT_CHAIN → NVIDIA_BRINGUP → PODMAN_SUBSTRATE → DESKTOP_SUBSTRATE
→ AI_SUBSTRATE → INFERENCE_SUBSTRATE → VALIDATION → FINALIZE
```

Each stage has:
- A re-entry probe that verifies on-disk reality before skipping on resume
- Explicit failure conditions with recovery options (retry, shell, abort)
- Per-stage log files with SHA256 consistency hashes

### Stage Summary

| Stage | Purpose | Destructive |
|-------|---------|-------------|
| PREFLIGHT | Verify environment, install `gum`/`fzf`, fetch keyrings, configure host APT | No |
| INPUT | Gather operator decisions (disk, pool name, hostname) | No |
| DISK_SAFETY | Wipe target disk with typed confirmation | **Yes** |
| ZFS_CREATE | Partition, create encrypted ZFS pool + datasets + EFI | **Yes** |
| BASE_INSTALL | Bootstrap Debian via mmdebstrap with pinned packages | Yes |
| BOOT_CHAIN | Configure dracut/ZBM, generate boot image, validate EFI, install UEFI fallback path | No |
| NVIDIA_BRINGUP | Install NVIDIA OpenDKMS, driver, CUDA toolkit, validate GPU | No |
| PODMAN_SUBSTRATE | Install and validate Podman | No |
| DESKTOP_SUBSTRATE | Install Sway desktop packages and `/etc/skel` defaults | No |
| AI_SUBSTRATE | Install AI venv/tooling and build llama.cpp with CUDA | No |
| INFERENCE_SUBSTRATE | Install cuDNN, Rust, build mistral.rs from source (~10-30 min) | No |
| VALIDATION | Run acabos-doctor invariant checks | No |
| FINALIZE | Generate manifest, copy logs, export pool | No |

Resume semantics note:
- On `--resume`, successful stages are probed before skip.
- `FINALIZE` is currently conservative and re-runs on resume.

## CLI Options

```
Usage: ./acabos-install [OPTIONS]

Options:
  --resume              Resume interrupted install from saved state
  --skip-gpu-validation Skip NVIDIA runtime validation (for VM/lab)
  --dev-mode            Build mistral.rs from source instead of pre-built
  --shell               Drop to recovery shell before starting
  --help                Show this help
```

## Post-Install

After FINALIZE completes:

1. Reboot the system
2. At the ZFSBootMenu console prompt, enter your passphrase to unlock the pool
3. Login with the user password configured during install
4. Rotate the password when prompted on first login
5. The system boots into the ACABOS workstation

Run `acabos-doctor` at any time to validate system invariants:

```bash
sudo /opt/acab/doctor/acabos-doctor
```

## Directory Structure

```
acabos-installer/
├── acabos-install              # Main entry point
├── lib/
│   ├── common.sh               # Logging, state, timeouts, chroot helpers
│   ├── topology.sh             # ZFS dataset hierarchy + property definitions
│   ├── detect_virt.sh          # Multi-signal hypervisor detection
│   ├── probes.sh               # Re-entry probes for resume logic
│   └── stage_*.sh              # One file per stage
├── config/
│   ├── apt-sources.list        # APT source configuration
│   ├── apt-preferences         # Package pin priorities
│   ├── apt-trust.conf          # APT security constraints
│   ├── cudnn.version           # cuDNN local repo pinning
│   ├── mistral.version         # mistral.rs version + features
│   ├── nvidia-keyring.sha256   # NVIDIA GPG key fingerprint
│   ├── zfsbootmenu-config.yaml # ZBM configuration
│   └── dracut.conf.d/zfs.conf  # dracut ZFS module config
├── doctor/
│   └── acabos-doctor           # Post-install validation tool
└── state/                      # Created at runtime
    ├── install-state.json      # State machine persistence
    ├── logs/                   # Per-stage logs
    └── manifest/               # Install manifest
```

## Documentation

- `docs/architecture.md` -- System design, dependency chain, trust model
- `docs/stage-reference.md` -- Per-stage contract reference
- `docs/deployment-readiness.md` -- Bare-metal production readiness gate checklist
- `docs/release-readiness-template.md` -- Fillable release gate artifact template
- `CONTRIBUTING.md` -- Development conventions and workflow

Code and docs governance:
- `acabos-install` `STAGE_ORDER` is the authoritative stage sequence.
- Docs are contract docs and must be updated in the same change when behavior changes.

## APT Trust Model

The installer scopes all APT trust to explicit keyrings:

| Source | Keyring | Scope |
|--------|---------|-------|
| Debian archive | `/usr/share/keyrings/debian-archive-keyring.gpg` | Host live env, mmdebstrap `--keyring=` |
| NVIDIA CUDA repo | `/usr/share/keyrings/nvidia-archive-keyring.gpg` | `signed-by=` in sources.list |
| cuDNN local repo | `/usr/share/keyrings/cudnn-local-*-keyring.gpg` | Ephemeral, embedded in local repo deb |

No ambient APT configuration inheritance. All sources use `signed-by=` scoping.

## NVIDIA Package Strategy

The installer uses NVIDIA's proprietary CUDA repository (Strategy B):

- **DKMS:** `nvidia-kernel-open-dkms` (595.x) from NVIDIA repo
- **Driver:** `nvidia-driver` (595.x) from NVIDIA repo -- version-locked with DKMS
- **CUDA:** `cuda-toolkit-13-2` from NVIDIA repo
- **cuDNN:** `cudnn9-cuda-13` from NVIDIA's local repo installer

These packages form a version-locked ecosystem. Debian's own NVIDIA packages (`nvidia-open-kernel-dkms`, `nvidia-cuda-toolkit`, 550.x) are incompatible and must not be mixed.

## ZFS Encryption

- Native ZFS encryption: `aes-256-gcm`
- `keyformat=passphrase`, `keylocation=prompt`
- Pool created with temporary keyfile, transitioned to passphrase, keyfile shredded
- No `org.zfsbootmenu:keysource` set (avoids circular dependency)
- No TPM binding in v0.1
