#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

# INPUT -- Gather operator decisions: target disk, pool name, hostname.
# Re-entry probe: lib/probes.sh probe_input()
run_input() {
  log "=== INPUT ==="

  log "Available disks:"
  local disks=()
  while IFS= read -r dev; do
    [[ -z "$dev" ]] && continue
    local model serial size
    model=$(disk_model "$dev")
    serial=$(disk_serial "$dev")
    size=$(disk_size "$dev")
    log "  $(basename "$dev")  model=${model}  serial=${serial}  size=${size}"
    disks+=("$(basename "$dev")")
  done < <(disks_by_id)

  echo ""
  local target_disk
  target_disk=$(prompt_select_disk "Select target disk by by-id basename (live partition preview enabled in fzf):" "${disks[@]}") \
    || fail "Disk selection aborted."
  [[ -e "/dev/disk/by-id/${target_disk}" ]] || fail "Selected disk does not exist: /dev/disk/by-id/${target_disk}"
  log "Selected disk: ${target_disk}"

  local pool_name=""
  while true; do
    local suffix
    suffix=$(hexdump -n 2 -e '2/1 "%02X"' /dev/urandom)
    pool_name="ACABROOT-${suffix}"
    log "Generated pool name: ${pool_name}"

    local collision=0
    if zpool list -H -o name 2>/dev/null | grep -q "^${pool_name}$"; then
      collision=1
    fi
    if zpool import 2>/dev/null | grep "pool:" | awk '{print $2}' | grep -q "^${pool_name}$"; then
      collision=1
    fi
    if [[ $collision -gt 0 ]]; then
      warn "Pool name collision detected: ${pool_name}. Regenerating..."
      continue
    fi

    echo ""
    echo "Pool name: ${pool_name}"
    if prompt_yn "Accept this pool name?"; then
      break
    fi
  done
  log "Pool name confirmed: ${pool_name}"

  echo ""
  hostname=$(prompt_text "Enter hostname")
  [[ -n "$hostname" ]] || fail "Hostname cannot be empty."
  log "Hostname: ${hostname}"

  echo ""
  username=$(prompt_text "Enter username for non-root account" "ai")
  [[ "$username" =~ ^[a-z_][a-z0-9_-]*$ ]] || fail "Invalid username: ${username}. Must start with lowercase letter or underscore, contain only lowercase letters, digits, underscores, hyphens."
  [[ "$username" != "root" && "$username" != "admin" ]] || fail "Username '${username}' is reserved."
  log "Username: ${username}"

  local timestamp
  timestamp=$(date -u +%Y%m%dT%H%M)
  local rand_suffix
  rand_suffix=$(hexdump -n 2 -e '2/1 "%02X"' /dev/urandom)
  local install_id="${timestamp}-${rand_suffix}"
  log "Install ID: ${install_id}"

  echo ""
  echo "============================================"
  echo "  INSTALL PLAN"
  echo "============================================"
  echo "  Target disk:    /dev/disk/by-id/${target_disk}"
  echo "  Pool name:      ${pool_name}"
  echo "  Hostname:       ${hostname}"
  echo "  Username:       ${username}"
  echo "  Install ID:     ${install_id}"
  echo "============================================"
  prompt_confirm "This will DESTROY ALL DATA on the selected disk. Review the plan above carefully."

  state_init "$install_id" "$pool_name" "$target_disk" "$hostname" "$username"
  log "State initialized. INPUT complete."
  return 0
}
