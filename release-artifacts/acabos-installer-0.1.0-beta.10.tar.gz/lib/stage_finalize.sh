#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

# FINALIZE -- Write manifest, create user, install first-boot service, export pool.
# Terminal stage. No re-entry probe.
run_finalize() {
  log "=== FINALIZE ==="

  local pool_name target_disk hostname install_id username
  pool_name=$(state_get_field "pool_name")
  target_disk=$(state_get_field "target_disk")
  hostname=$(state_get_field "hostname")
  install_id=$(state_get_field "install_id")
  username=$(state_get_field "username")
  local target="/mnt/install"
  local user_password="${ACABOS_USER_PASSWORD:-}"

  if [[ -z "$user_password" ]]; then
    if is_interactive; then
      local password_confirm
      user_password=$(prompt_password "Enter initial password for ${username}")
      [[ -n "$user_password" ]] || fail "User password cannot be empty."
      password_confirm=$(prompt_password "Confirm password for ${username}")
      [[ "$user_password" == "$password_confirm" ]] || fail "Password confirmation did not match."
    else
      fail "No interactive TTY for password prompt. Set ACABOS_USER_PASSWORD to continue."
    fi
  fi

  log "Creating non-root user: ${username}..."
  chroot_mount "$target"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" useradd -m -s /bin/bash -G sudo,plugdev,netdev,audio,video,systemd-journal "$username" \
    || { chroot_umount "$target"; fail "Failed to create user ${username}"; }
  printf '%s:%s\n' "$username" "$user_password" | run_timeout "$SHORT_TIMEOUT" chroot "$target" chpasswd \
    || { chroot_umount "$target"; fail "Failed to set initial password"; }
  run_timeout "$SHORT_TIMEOUT" chroot "$target" chage -d 0 "$username" \
    || warn "Failed to require password rotation for user ${username}"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" loginctl enable-linger "$username" 2>/dev/null \
    || warn "Failed to enable linger for user ${username}"
  chroot_umount "$target"
  user_password=""
  log "User ${username} created (forced password change on first login)."

  log "Locking root account..."
  chroot_mount "$target"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" passwd -l root 2>/dev/null || warn "Failed to lock root account"
  chroot_umount "$target"
  log "Root account locked."

  local user_home="${target}/home/${username}"
  chroot_mount "$target"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" chown -R "${username}:${username}" "/home/${username}" \
    || warn "Failed to set ownership on user home"
  chroot_umount "$target"
  log "User home ownership set."

  log "Installing user-level Ollama container..."
  local user_quadlet_dir="${user_home}/.config/containers/systemd/user"
  mkdir -p "$user_quadlet_dir"
  cp "${INSTALLER_DIR}/config/quadlets/ollama.container" "${user_quadlet_dir}/ollama-user.container"
  sed -i 's/ContainerName=ollama/ContainerName=ollama-user/' "${user_quadlet_dir}/ollama-user.container"
  sed -i 's/PublishPort=11434:11434/PublishPort=11435:11434/' "${user_quadlet_dir}/ollama-user.container"
  sed -i 's/Volume=ollama-data/Volume=ollama-user-data/' "${user_quadlet_dir}/ollama-user.container"
  sed -i 's/WantedBy=multi-user.target/WantedBy=default.target/' "${user_quadlet_dir}/ollama-user.container"
  chroot_mount "$target"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" chown -R "${username}:${username}" "/home/${username}/.config" \
    || warn "Failed to set ownership on user .config"
  chroot_umount "$target"
  log "User-level Ollama container installed."

  log "Installing sudoers configuration..."
  cp "${INSTALLER_DIR}/config/sudoers-acabos" "${target}/etc/sudoers.d/99-acabos"
  chmod 440 "${target}/etc/sudoers.d/99-acabos"
  log "Sudoers configured."

  log "Installing first-boot service..."
  cp "${INSTALLER_DIR}/config/first-boot.service" "${target}/etc/systemd/system/first-boot.service"
  cp "${INSTALLER_DIR}/config/first-boot-setup" "${target}/usr/local/bin/first-boot-setup"
  chmod 755 "${target}/usr/local/bin/first-boot-setup"
  mkdir -p "${target}/etc/acabos"
  chroot_mount "$target"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" systemctl enable first-boot.service 2>/dev/null \
    || warn "Failed to enable first-boot service"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" systemctl enable NetworkManager 2>/dev/null \
    || warn "Failed to enable NetworkManager"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" systemctl enable apparmor 2>/dev/null \
    || warn "Failed to enable apparmor"
  chroot_umount "$target"
  log "First-boot service installed."

  log "Creating MOTD..."
  cp "${INSTALLER_DIR}/config/motd" "${target}/etc/motd"
  log "MOTD installed."

  log "Installing /etc/issue..."
  cp "${INSTALLER_DIR}/config/issue" "${target}/etc/issue" \
    || fail "Failed to install /etc/issue"
  log "/etc/issue installed."

  log "Generating install manifest..."

  local kernel_ver headers_ver zfs_ver nvidia_ver podman_ver
  local py_ver torch_ver
  chroot_mount "$target"
  kernel_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" dpkg-query -W -f='${Version}' linux-image-amd64 2>/dev/null || echo "unknown")
  headers_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" dpkg-query -W -f='${Version}' linux-headers-amd64 2>/dev/null || echo "unknown")
  zfs_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" dpkg-query -W -f='${Version}' zfsutils-linux 2>/dev/null || echo "unknown")
  nvidia_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" dpkg-query -W -f='${Version}' nvidia-driver 2>/dev/null || echo "unknown")
  podman_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" podman --version 2>/dev/null | awk '{print $3}' || echo "unknown")
  py_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" /opt/ai-venv/bin/python --version 2>/dev/null | awk '{print $2}' || echo "unknown")
  torch_ver=$(run_timeout "$SHORT_TIMEOUT" chroot "$target" /opt/ai-venv/bin/python -c 'import torch; print(torch.__version__)' 2>/dev/null || echo "unknown")
  chroot_umount "$target"

  local log_artifacts="[]"
  for stage in "${!STAGE_LOG_HASHES[@]}"; do
    local entry="${STAGE_LOG_HASHES[$stage]}"
    local log_path log_hash
    log_path=$(echo "$entry" | cut -d'|' -f2)
    log_hash=$(echo "$entry" | cut -d'|' -f3)
    log_artifacts=$(echo "$log_artifacts" | jq \
      --arg p "/opt/acab/logs/install/$(basename "$log_path")" \
      --arg h "$log_hash" \
      '. += [{"path": $p, "kind": "install_log", "sha256": $h}]')
  done

  local pool_guid
  pool_guid=$(zpool get -H -o value guid "$pool_name" 2>/dev/null || echo "unknown")

  jq -n \
    --arg sv "acabos-install-manifest/v2" \
    --arg mk "install_manifest" \
    --arg iid "$install_id" \
    --arg ts "$(iso_timestamp)" \
    --arg hn "$hostname" \
    --arg td "$target_disk" \
    --arg pn "$pool_name" \
    --arg pg "$pool_guid" \
    --arg kv "$kernel_ver" \
    --arg hv "$headers_ver" \
    --arg zv "$zfs_ver" \
    --arg nv "$nvidia_ver" \
    --arg pv "$podman_ver" \
    --arg tv "$TOPOLOGY_VERSION" \
    --arg dsv "$DOCTOR_SCHEMA_VERSION" \
    --arg un "$username" \
    --arg pyv "$py_ver" \
    --arg tv2 "$torch_ver" \
    --argjson la "$log_artifacts" \
    -f "${INSTALLER_DIR}/config/manifest-template.jq" \
    > "${MANIFEST_DIR}/install-manifest.json"

  log "Manifest generated."

  log "Copying manifest into installed system..."
  mkdir -p "${target}/opt/acab/manifests" "${target}/opt/acab/logs/install"
  cp "${MANIFEST_DIR}/install-manifest.json" "${target}/opt/acab/manifests/install-manifest.json"
  log "Manifest copied."

  log "Copying logs into installed system..."
  for logf in "${LOG_DIR}/"*.log; do
    [[ -f "$logf" ]] || continue
    cp "$logf" "${target}/opt/acab/logs/install/"
  done
  for hashf in "${LOG_DIR}/"*.sha256; do
    [[ -f "$hashf" ]] || continue
    cp "$hashf" "${target}/opt/acab/logs/install/"
  done
  log "Logs copied."

  log "Running best-effort post-install cleanup..."
  chroot_mount "$target"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" env LANG=C.UTF-8 LC_ALL=C.UTF-8 apt-get clean 2>/dev/null || warn "apt-get clean failed"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" env LANG=C.UTF-8 LC_ALL=C.UTF-8 apt-get autoclean 2>/dev/null || warn "apt-get autoclean failed"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" updatedb 2>/dev/null || warn "updatedb failed"
  run_timeout "$SHORT_TIMEOUT" chroot "$target" update-desktop-database /usr/share/applications 2>/dev/null || warn "update-desktop-database failed"
  chroot_umount "$target"
  log "Cleanup complete."

  log "Exporting pool..."
  run_timeout "$SHORT_TIMEOUT" zpool export "$pool_name" \
    || fail "Failed to export pool ${pool_name}"
  log "Pool exported."

  echo ""
  echo "============================================"
  echo "  ACABOS INSTALL COMPLETE"
  echo "============================================"
  echo "  Pool:     ${pool_name}"
  echo "  Disk:     /dev/disk/by-id/${target_disk}"
  echo "  Hostname: ${hostname}"
  echo "  User:     ${username}"
  echo "  Kernel:   ${kernel_ver}"
  echo "  ZFS:      ${zfs_ver}"
  echo "  NVIDIA:   ${nvidia_ver}"
  echo "  Podman:   ${podman_ver}"
  echo "  Python:   ${py_ver}"
  echo "  PyTorch:  ${torch_ver}"
  echo ""
  echo "  Post-install steps:"
  echo "  1. Reboot the system."
  echo "  2. At the ZFSBootMenu prompt, enter your"
  echo "     passphrase to unlock ${pool_name}."
  echo "  3. Login as ${username} with the password"
  echo "     configured during installation."
  echo "  4. Change the password when prompted on first login."
  echo "  5. Run start-desktop to launch Sway."
  echo "============================================"

  log "FINALIZE complete."
  return 0
}
