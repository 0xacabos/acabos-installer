# Contributing to ACABOS Installer

## Design Philosophy

This project is **contract-driven**.

- Runtime behavior is implemented in code.
- `docs/architecture.md` and `docs/stage-reference.md` define expected contracts.
- If code and docs diverge, fix both in the same change.

## Change Workflow

1. Identify the change needed
2. Update implementation
3. Update docs (`README.md`, `docs/architecture.md`, `docs/stage-reference.md`) when behavior changes
4. Run `bash -n` on all modified shell files
5. Verify config files are shell-sourceable (for `config/*.version` files)

## Code Conventions

### Shell Standards

Every file begins with:

```bash
#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
```

No exceptions. No file may be sourced without these guards.

### Logging Functions

Use the provided logging functions from `lib/common.sh`:

- `log "message"` -- informational output + tee to stage log
- `warn "message"` -- warning to stderr + tee to stage log
- `err "message"` -- error to stderr + tee to stage log
- `fail "message"` -- error + `exit 1`

Always use `"$*"` for multi-word messages. Never use bare `"$"` for logging.

### Timeouts

All external command calls must be wrapped with `run_timeout`:

```bash
run_timeout "$SHORT_TIMEOUT" command ...    # 30s - probes, status checks
run_timeout "$MEDIUM_TIMEOUT" command ...   # 120s - keyring fetch, apt update
run_timeout "$LONG_TIMEOUT" command ...     # 600s - apt install, mmdebstrap
run_timeout "$BUILD_TIMEOUT" command ...    # 3600s - cargo install
```

Never use bare `timeout` directly.

### Error Handling

- The global ERR trap in `common.sh` handles unhandled errors
- `run_timeout` owns its own failure reporting (124/137 exit codes)
- Stage functions should use `|| fail "descriptive message"` for fatal errors
- Use `|| true` for non-fatal best-effort commands
- Chroot mounts must always be paired with `chroot_umount` in failure paths

### State Management

- Read state: `state_get_field "field_name"`
- Read stage status: `state_get_stage_status "STAGE_NAME"`
- Stage lifecycle: `state_set_stage` → `state_complete_stage` or `state_fail_stage`
- State file is at `state/install-state.json`

### File Organization

| Location | Purpose |
|----------|---------|
| `acabos-install` | Entry point only. No stage logic. |
| `lib/stage_*.sh` | One file per stage. Exports `run_<stage>()`. |
| `lib/common.sh` | Shared utilities. No stage-specific logic. |
| `lib/topology.sh` | Dataset definitions. No runtime logic. |
| `lib/detect_virt.sh` | Hypervisor detection. Self-contained. |
| `lib/probes.sh` | Re-entry probes. One function per stage. |
| `config/*` | Static configuration. Not generated at runtime. |
| `doctor/acabos-doctor` | Standalone validation. No dependency on installer state. |

### Comments

Do not add comments unless explaining non-obvious behavior. Docs and stage contracts are the documentation.

### No `eval`

Never use `eval`. The doctor uses function-based dispatch via associative arrays. If you need dynamic dispatch, use the same pattern.

## Key Architectural Constraints

### ZFS Pool Naming

Pools must be named `ACABROOT-XXXX` where `XXXX` is 4 hex characters. Generated via:
```bash
hexdump -n 2 -e '2/1 "%02X"' /dev/urandom
```

### Disk Operations

All disk operations must use `/dev/disk/by-id` paths. Never use `/dev/sdX` or `/dev/nvmeXnY`.

### APT Trust

- `mmdebstrap` uses `--keyring=` with explicit keyring path
- NVIDIA repo uses `signed-by=` in sources.list
- cuDNN local repo has its own embedded GPG key
- `config/apt-trust.conf` enforces `AllowUnauthenticated "false"`

### Version-Locked Pairs

NVIDIA DKMS and driver packages are version-locked. They must come from the same repository. Mixing NVIDIA repo packages with Debian's NVIDIA packages will fail.

### Encryption Key Behavior

- No keyfile on disk after install
- No `org.zfsbootmenu:keysource` on any dataset
- Temporary keyfile created during ZFS_CREATE, shredded after passphrase transition

## Making Changes

### Adding a New Stage

1. Add/update stage contract in `docs/stage-reference.md`
2. Create `lib/stage_<name>.sh` with `run_<name>()` function
3. Add a re-entry probe in `lib/probes.sh`
4. Register the stage in `acabos-install` (`STAGE_ORDER` and `STAGE_FUNCS`)
5. Add doctor checks if applicable
6. Update `docs/architecture.md` and `README.md` stage summary

### Changing Package Pinning

1. Update `config/apt-preferences`
2. Update `docs/architecture.md` package strategy section
3. Verify pin resolution: `apt-cache policy <package>` inside the target environment

### Changing ZFS Topology

1. Update `lib/topology.sh` (dataset list + property map)
2. Increment `TOPOLOGY_VERSION` in `lib/common.sh`
3. Update `docs/architecture.md` storage layout section
4. Update the probe in `lib/probes.sh` (bidirectional verification)
5. Update doctor checks that reference topology
