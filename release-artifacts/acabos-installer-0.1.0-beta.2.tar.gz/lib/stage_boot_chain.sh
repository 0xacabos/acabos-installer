#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

# BOOT_CHAIN -- Configure dracut/ZBM, kernel params, nvidia modprobe, sysctl, ZFS tuning.
# Re-entry probe: lib/probes.sh probe_boot_chain()
run_boot_chain() {
  log "=== BOOT_CHAIN ==="

  local pool_name
  pool_name=$(state_get_field "pool_name")
  local target_disk
  target_disk=$(state_get_field "target_disk")
  local target="/mnt/install"

  log "Installing ZFSBootMenu from source..."
  local zbm_version="v3.1.0"
  chroot_mount "$target"
  run_timeout "$MEDIUM_TIMEOUT" chroot "$target" env LANG=C.UTF-8 LC_ALL=C.UTF-8 apt-get update \
    || { chroot_umount "$target"; fail "apt-get update failed in target"; }
  run_timeout "$MEDIUM_TIMEOUT" chroot "$target" env LANG=C.UTF-8 LC_ALL=C.UTF-8 apt-get install -y perl kexec-tools libsort-versions-perl libyaml-pp-perl libboolean-perl \
    || { chroot_umount "$target"; fail "Failed to install ZFSBootMenu dependencies"; }
  run_timeout "$MEDIUM_TIMEOUT" chroot "$target" bash -c "curl -fsSL https://github.com/zbm-dev/zfsbootmenu/archive/refs/tags/${zbm_version}.tar.gz | tar xz -C /tmp && cd /tmp/zfsbootmenu-* && make install" \
    || { chroot_umount "$target"; fail "ZFSBootMenu installation failed"; }
  run_timeout "$SHORT_TIMEOUT" chroot "$target" rm -rf /tmp/zfsbootmenu-*
  chroot_umount "$target"
  log "ZFSBootMenu ${zbm_version} installed."

  log "Installing dracut configuration..."
  cp "${INSTALLER_DIR}/config/dracut.conf.d/zfs.conf" "${target}/etc/dracut.conf.d/zfs.conf" \
    || fail "Failed to install dracut config"
  log "dracut config installed."

  log "Installing ZFSBootMenu configuration..."
  mkdir -p "${target}/etc/zfsbootmenu"
  cp "${INSTALLER_DIR}/config/zfsbootmenu-config.yaml" "${target}/etc/zfsbootmenu/config.yaml" \
    || fail "Failed to install ZBM config"
  log "ZBM config installed."

  log "Installing /etc/default/zfs..."
  cat > "${target}/etc/default/zfs" << 'ZFS_DEFAULT'
ZFS_IMPORT='cache'
ZFS_MOUNT='yes'
ZFS_SHARE='yes'
ZFS_VERBOSE='no'
ZFS_DEFAULT
  log "/etc/default/zfs installed."

  log "Installing ZFSBootMenu dracut conf.d..."
  mkdir -p "${target}/etc/zfsbootmenu/dracut.conf.d"
  cat > "${target}/etc/zfsbootmenu/dracut.conf.d/10-acabos.conf" << 'ZBM_DRACUT'
add_dracutmodules+=" zfs "
omit_dracutmodules+=" nvidia "
install_items+=" /etc/zfs/zpool.cache /etc/default/zfs "
ZBM_DRACUT
  log "ZFSBootMenu dracut conf.d installed."

  log "Setting kernel command line..."
  local zbm_cmdline="${target}/etc/zfsbootmenu/cmdline"
  cat > "$zbm_cmdline" << 'CMDLINE'
nvidia-drm.modeset=1 nvidia-drm.fbdev=1 nvidia.NVreg_UsePageAttributeTable=1 nvidia.NVreg_RegistryDwords=OverridePagePromotion=0x3000001 console=tty0 console=ttyS0,115200n8 quiet loglevel=3
CMDLINE
  log "Kernel cmdline set."

  log "Installing NVIDIA modprobe configurations..."
  cp "${INSTALLER_DIR}/config/nvidia-modprobe/nvidia.conf" "${target}/etc/modprobe.d/nvidia.conf"
  cp "${INSTALLER_DIR}/config/nvidia-modprobe/nvidia-drm.conf" "${target}/etc/modprobe.d/nvidia-drm.conf"
  cp "${INSTALLER_DIR}/config/nvidia-modprobe/nvidia-uvm.conf" "${target}/etc/modprobe.d/nvidia-uvm.conf"
  log "  NVIDIA modprobe configs installed."

  log "Installing NVIDIA udev rules..."
  cp "${INSTALLER_DIR}/config/nvidia-udev/70-nvidia.rules" "${target}/etc/udev/rules.d/70-nvidia.rules"
  log "  NVIDIA udev rules installed."

  log "Installing sysctl tuning..."
  cp "${INSTALLER_DIR}/config/sysctl/99-hugepages.conf" "${target}/etc/sysctl.d/99-hugepages.conf"
  cp "${INSTALLER_DIR}/config/sysctl/99-performance.conf" "${target}/etc/sysctl.d/99-performance.conf"
  log "  Sysctl tuning installed."

  log "Installing ZFS module tuning..."
  cp "${INSTALLER_DIR}/config/zfs-tuning.conf" "${target}/etc/modprobe.d/zfs.conf"
  log "  ZFS module tuning installed."

  log "Generating boot image..."
  local efi_part="/dev/disk/by-id/${target_disk}-part1"
  mkdir -p "${target}/boot/efi"
  if ! mountpoint -q "${target}/boot/efi"; then
    run_timeout "$SHORT_TIMEOUT" mount "$efi_part" "${target}/boot/efi" \
      || fail "Failed to mount EFI partition at ${target}/boot/efi"
  fi
  chroot_mount "$target"
  local target_kernel
  target_kernel=$(ls "${target}/lib/modules/" 2>/dev/null | head -1 || echo "")
  [[ -n "$target_kernel" ]] || { chroot_umount "$target"; fail "No kernel found in target"; }
  mkdir -p "${target}/boot/efi/EFI/zfsbootmenu"
  mkdir -p "${target}/boot/efi/EFI/BOOT"
  run_timeout "$MEDIUM_TIMEOUT" chroot "$target" dracut -f /boot/efi/EFI/zfsbootmenu/initramfs.img "$target_kernel" \
    || { chroot_umount "$target"; fail "dracut failed"; }
  cp "${target}/boot/vmlinuz-${target_kernel}" "${target}/boot/efi/EFI/zfsbootmenu/vmlinuz-${target_kernel}" \
    || { chroot_umount "$target"; fail "Failed to copy kernel to EFI"; }
  cp "${target}/boot/vmlinuz-${target_kernel}" "${target}/boot/efi/EFI/BOOT/BOOTX64.EFI" \
    || warn "Failed to install fallback EFI loader path"
  chroot_umount "$target"
  log "Boot image generated."

  log "Ensuring EFI mount for validation..."
  if ! mountpoint -q "${target}/boot/efi"; then
    run_timeout "$SHORT_TIMEOUT" mount "$efi_part" "${target}/boot/efi" \
      || warn "Failed to mount EFI partition for validation"
  fi

  log "Validating EFI partition..."
  validate_efi_partition

  if command -v efibootmgr >/dev/null 2>&1; then
    log "Attempting EFI boot entry registration (best effort)..."
    register_efi_boot_entry || warn "EFI boot entry registration failed"
  else
    warn "efibootmgr not available in live environment; skipping EFI boot entry registration"
  fi

  log "Running pool import test..."
  local pool_exported
  pool_exported=$(zpool list -H -o name 2>/dev/null | grep -c "^${pool_name}$" || echo "0")
  if [[ "$pool_exported" -gt 0 ]]; then
    run_timeout "$SHORT_TIMEOUT" zpool export "$pool_name" || warn "Failed to export pool for import test"
    chroot_mount "$target"
    run_timeout "$SHORT_TIMEOUT" chroot "$target" zpool import -N -o readonly=on "$pool_name" \
      || { chroot_umount "$target"; warn "Pool import test failed (non-fatal for altroot installs)"; }
    run_timeout "$SHORT_TIMEOUT" zpool import "$pool_name" -R /mnt/install 2>/dev/null \
      || warn "Failed to restore writable pool import after import test"
    chroot_umount "$target"
  fi

  log "BOOT_CHAIN complete."
  return 0
}

register_efi_boot_entry() {
  local efi_mount="/mnt/install/boot/efi"
  local efi_src
  efi_src=$(findmnt -n -o SOURCE "$efi_mount" 2>/dev/null || echo "")
  [[ -n "$efi_src" ]] || return 1

  local efi_dev
  efi_dev=$(readlink -f "$efi_src" 2>/dev/null || echo "")
  [[ -n "$efi_dev" && -b "$efi_dev" ]] || return 1

  local efi_disk
  efi_disk=$(lsblk -no PKNAME "$efi_dev" 2>/dev/null | head -1 || echo "")
  [[ -n "$efi_disk" ]] || return 1

  local efi_partnum
  efi_partnum=$(lsblk -no PARTNUM "$efi_dev" 2>/dev/null | head -1 || echo "")
  [[ -n "$efi_partnum" ]] || return 1

  local efi_loader
  efi_loader=$(ls -1 "${efi_mount}/EFI/zfsbootmenu/vmlinuz-"* 2>/dev/null | head -1 || echo "")
  [[ -n "$efi_loader" ]] || return 1

  local efi_initramfs
  efi_initramfs=$(ls -1 "${efi_mount}/EFI/zfsbootmenu/initramfs-"* 2>/dev/null | head -1 || true)
  if [[ -z "$efi_initramfs" ]]; then
    efi_initramfs=$(ls -1 "${efi_mount}/EFI/zfsbootmenu/initramfs.img" 2>/dev/null | head -1 || true)
  fi
  [[ -n "$efi_initramfs" ]] || return 1

  local loader_rel="\\EFI\\zfsbootmenu\\$(basename "$efi_loader")"
  local initrd_rel="\\EFI\\zfsbootmenu\\$(basename "$efi_initramfs")"
  local cmdline_file="/mnt/install/etc/zfsbootmenu/cmdline"
  local cmdline_opts=""
  if [[ -r "$cmdline_file" ]]; then
    cmdline_opts=$(tr '\n' ' ' < "$cmdline_file" | sed 's/[[:space:]]\+/ /g; s/^ //; s/ $//')
  fi
  local boot_opts="initrd=${initrd_rel}"
  if [[ -n "$cmdline_opts" ]]; then
    boot_opts="${boot_opts} ${cmdline_opts}"
  fi

  run_timeout "$SHORT_TIMEOUT" efibootmgr -c -d "/dev/${efi_disk}" -p "$efi_partnum" \
    -L "ACABOS ZFSBootMenu" -l "$loader_rel" -u "$boot_opts" >/dev/null 2>&1 || return 1
  return 0
}

validate_efi_partition() {
  local efi_mount="/mnt/install/boot/efi"

  local efi_device
  efi_device=$(findmnt -n -o SOURCE "$efi_mount" 2>/dev/null || echo "")
  [[ -n "$efi_device" ]] || fail "EFI partition not mounted"

  run_timeout "$SHORT_TIMEOUT" dosfsck -n "$efi_device" 2>&1 || warn "dosfsck reported issues (may be benign)"

  local total_size=0
  local f
  for f in "${efi_mount}/EFI/zfsbootmenu/"*; do
    [[ -f "$f" ]] || continue
    local sz
    sz=$(stat -c '%s' "$f" 2>/dev/null || echo 0)
    total_size=$((total_size + sz))
  done
  local margin=$(( total_size / 10 ))
  local required=$(( total_size + margin ))
  local free_bytes
  free_bytes=$(df -B1 -P "$efi_mount" 2>/dev/null | awk 'NR==2{print $4}')
  if [[ -n "$free_bytes" && "$free_bytes" -lt "$required" ]]; then
    fail "EFI partition insufficient free space: ${free_bytes} bytes free, ${required} bytes required"
  fi

  local zbm_kernel zbm_initramfs
  zbm_kernel=$(ls -1 "${efi_mount}/EFI/zfsbootmenu/vmlinuz-"* 2>/dev/null | head -1 || echo "")
  if [[ -z "$zbm_kernel" || ! -r "$zbm_kernel" || ! -s "$zbm_kernel" ]]; then
    fail "ZBM kernel missing/empty on EFI partition"
  fi

  zbm_initramfs=$(ls -1 "${efi_mount}/EFI/zfsbootmenu/initramfs"* 2>/dev/null | head -1 || echo "")
  if [[ -z "$zbm_initramfs" || ! -r "$zbm_initramfs" || ! -s "$zbm_initramfs" ]]; then
    fail "ZBM initramfs missing/empty on EFI partition"
  fi

  local has_zfs=0
  if run_timeout "$SHORT_TIMEOUT" lsinitrd "$zbm_initramfs" 2>&1 | grep -q zfs; then
    has_zfs=1
  elif run_timeout "$MEDIUM_TIMEOUT" bash -c "zcat '$zbm_initramfs' | cpio -t 2>/dev/null | grep -q 'zfs\.ko'"; then
    has_zfs=1
  else
    warn "lsinitrd could not confirm ZFS modules; checking file size as fallback"
    local initramfs_size
    initramfs_size=$(stat -c '%s' "$zbm_initramfs" 2>/dev/null || echo 0)
    [[ "$initramfs_size" -gt 10485760 ]] && has_zfs=1
  fi
  [[ "$has_zfs" -eq 1 ]] || fail "EFI initramfs does not contain ZFS modules"

  if [[ ! -s "${efi_mount}/EFI/BOOT/BOOTX64.EFI" ]]; then
    warn "UEFI fallback loader missing at /EFI/BOOT/BOOTX64.EFI"
  fi

  log "EFI partition validated: integrity OK, space OK, artifacts present, ZFS modules confirmed."
}
