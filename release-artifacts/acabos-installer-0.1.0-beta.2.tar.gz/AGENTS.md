# ACABOS Installer Agent Guide

## Commands
- Run installer: `sudo ./acabos-install [--resume] [--skip-gpu-validation] [--dev-mode] [--shell]`
- Validate install: `sudo /opt/acab/doctor/acabos-doctor`
- Lint shell: `bash -n <file>` on modified shell files
- Validate config: `source config/<name>.version` (e.g., `source config/mistral.version`) — these are shell-sourceable files that define version-pinned variables

## Architecture
- 13 ordered resumable stages: `acabos-install:34-48` defines `STAGE_ORDER` — this is authoritative
- State persisted in `state/install-state.json` via jq; resume version-matches `STATE_VERSION` constant
- `common.sh` auto-calls `init_paths()` at line 331 — no manual init needed
- `lib/topology.sh` requires explicit `build_topology "$pool_name"` call to populate `TOPOLOGY_DATASETS`, `TOPOLOGY_PROPS`, `TOPOLOGY_MOUNTPOINTS` globals
- Doctor: 22 checks across 7 domains with skip semantics — if a prerequisite fails, dependents are marked "skip" not "fail" to prevent cascade noise
- `DOCTOR_SCHEMA_VERSION` in common.sh (v1) feeds the installer banner and manifest; the doctor binary uses its own `DOCTOR_SCHEMA` (v2) — discrepancy not yet reconciled

## Stale references
- README lists 11 stages (missing DESKTOP_SUBSTRATE and AI_SUBSTRATE) — code is authoritative
- README CLI options section omits `--dev-mode` — see `acabos-install` usage() for the real list
- `docs/acabos-installer-spec.md` does not exist in this checkout, but is referenced by CONTRIBUTING.md and `lib/stage_*.sh` header comments (e.g., "Spec reference: docs/acabos-installer-spec.md Section 4.1"). Available docs: `docs/architecture.md`, `docs/stage-reference.md`
- CHANGES.md documents debug-era modifications: hardcoded passwords ("birdleaf"), `prompt_confirm()` disabled, and other deviations from a clean install flow

## Constraints
- ZFS pools: `ACABROOT-XXXX` (4 hex chars via `hexdump -n 2 -e '2/1 "%02X"' /dev/urandom`)
- Disk paths: `/dev/disk/by-id` only, never `/dev/sdX`
- APT: explicit keyrings (`--keyring=`, `signed-by=`), no ambient trust
- NVIDIA packages: from NVIDIA repo only, version-locked with Debian's incompatible
- Encryption: temporary keyfile shredded, `keylocation=prompt`, no `org.zfsbootmenu:keysource`
- `TOPOLOGY_VERSION` in `common.sh` must be incremented when `lib/topology.sh` structure changes

## Code Conventions
- Every file: `set -Eeuo pipefail; IFS=$'\n\t'`
- Logging: `log`, `warn`, `err`, `fail` functions
- Timeouts: `run_timeout "$SHORT_TIMEOUT"` (30s), `"$MEDIUM_TIMEOUT"` (120s), `"$LONG_TIMEOUT"` (600s), `"$BUILD_TIMEOUT"` (3600s) — never bare `timeout`
- No `eval`; use associative array dispatch
- State: `state_get_field`, `state_set_stage`, `state_complete_stage`, `state_fail_stage`
- No comments unless non-obvious; spec is docs
- `acabos-install` main body uses `local` outside functions (lines 207-221) — works in bash but technically incorrect; don't replicate this pattern

## Adding a new stage
1. Create `lib/stage_<name>.sh` with `run_<name>()` function
2. Add re-entry probe in `lib/probes.sh`
3. Register in `acabos-install`: `STAGE_ORDER` array + `STAGE_FUNCS` associative array
4. Source the new file in `acabos-install`
5. Add doctor checks if applicable
6. Update `docs/stage-reference.md`

## Runtime gotchas
- `prompt_confirm()` is currently hardcoded to return `true` (automation mode) — `prompt_yn()` still works interactively but has debug `err` logging of trimmed response at `common.sh:124`
- FINALIZE log claims "forced password change on first login" but `chage -d 0` is commented out — password is hardcoded to "birdleaf" with no forced rotation
- `inputs.txt` provides pre-seeded answers for automated runs — format is line-delimited: `target_disk_id`, `confirm_y`, `hostname`, `username`, `disk_id_again`
- Per-stage logs with SHA256 consistency hashes written to `state/logs/<STAGE>.log.sha256`
- Chroot mounts must be paired with `chroot_umount` in failure paths
- `prepare_dataset_rerun` exists for re-running BASE_INSTALL without re-partitioning
- FINALIZE probe always returns 1 — it always re-runs on resume
- `--dev-mode` flag sets `ACABOS_DEV_MODE` env var; used to build mistral.rs from source instead of using pre-built binary
- Pool busy errors between runs may require reboot to clear
- Live environment needs kernel headers installed and ZFS module loaded before running installer
