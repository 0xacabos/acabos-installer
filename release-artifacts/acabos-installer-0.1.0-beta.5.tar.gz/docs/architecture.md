# Architecture

## System Design

ACABOS is a Bash state machine that runs from a Debian Trixie live session and provisions a baseline AI workstation in 13 ordered, resumable stages.

## Stage Flow

```
PREFLIGHT
  -> INPUT
  -> DISK_SAFETY
  -> ZFS_CREATE
  -> BASE_INSTALL
  -> BOOT_CHAIN
  -> NVIDIA_BRINGUP
  -> PODMAN_SUBSTRATE
  -> DESKTOP_SUBSTRATE
  -> AI_SUBSTRATE
  -> INFERENCE_SUBSTRATE
  -> VALIDATION
  -> FINALIZE
```

Interactive UX model:

- Prompt primitives are centralized in `lib/common.sh`.
- `gum` is used for interactive prompts when available.
- Disk selection prefers `fzf` with live partition/signature preview.
- Non-interactive runs retain shell/stdin-compatible fallback behavior.

State is persisted in `state/install-state.json` and includes:

- `state_version`
- `install_id`
- `current_stage`
- `pool_name`
- `target_disk`
- `hostname`
- `username`
- per-stage status/timestamps

Resume behavior:

- Successful stages are probed before being skipped on `--resume`.
- Failed or in-progress stages are re-run.
- `FINALIZE` is currently conservative and re-runs on resume.

## Storage Layout

Installer creates pool `ACABROOT-XXXX` with `ashift=12`, encryption enabled, and bootfs set to `ROOT/acabos`.

`ashift` policy:

- `ashift=12` is fixed by design across NVMe and SATA drives.
- The installer does not branch `ashift` by drive naming convention (`nvme*` vs `sd*`) or media class.
- This prioritizes deterministic pool behavior and simpler operational support over per-device adaptive tuning.

Dataset topology includes:

- `${pool}/ROOT/acabos` mounted at `/`
- `${pool}/opt/acab/*` for ACAB runtime assets
- `${pool}/opt/ai-venv` mounted at `/opt/ai-venv`
- `${pool}/opt/llama-cpp` mounted at `/opt/llama-cpp`
- `${pool}/var/lib/containers`, `${pool}/var/log`, `${pool}/var/cache`, `${pool}/var/tmp`
- `${pool}/home`
- `${pool}/swap` zvol (size ~= RAM)

Key constraints:

- no `org.zfsbootmenu:keysource`
- keyfile is temporary and shredded
- encryption transitions to `keylocation=prompt`

## Boot Chain

BOOT_CHAIN installs and validates:

- dracut config (`config/dracut.conf.d/zfs.conf`)
- ZFSBootMenu config (`config/zfsbootmenu-config.yaml`)
- `/etc/default/zfs`
- ZBM dracut conf (`/etc/zfsbootmenu/dracut.conf.d/10-acabos.conf`)
- NVIDIA modprobe and udev configs
- sysctl performance tuning

Kernel cmdline includes NVIDIA DRM/KMS options. EFI artifacts are validated. Boot chain now performs both:

- NVRAM boot entry registration via `efibootmgr` with explicit `initrd=` argument.
- fallback UEFI loader install at `/EFI/BOOT/BOOTX64.EFI`.

## Package Strategy

APT trust and pinning are explicit:

- Debian trixie base
- trixie-backports cohort pinning
- NVIDIA CUDA repo pinning
- NVIDIA Container Toolkit repo pinning
- cuDNN local repo during inference stage

BASE_INSTALL installs boot/runtime essentials via mmdebstrap include list, including ZFS, dracut, ZBM, Python toolchain basics, and ZED.

PREFLIGHT installs `gum` and `fzf` into the live environment as required UI dependencies.

## NVIDIA + Runtime Substrates

NVIDIA_BRINGUP installs:

- `nvidia-kernel-open-dkms`
- `nvidia-driver`
- `cuda-toolkit-13-2` (+ CUDA libs/dev/CLI/NVML packages)
- `nvidia-container-toolkit`
- `nvidia-persistenced`

Validation is two-phase:

- build validation (DKMS/module files)
- runtime validation (strict on physical hardware, warning-only in virtual contexts)

PODMAN_SUBSTRATE installs Podman/buildah/skopeo/netavark stack and writes container configs plus CDI spec.

## Desktop + AI Substrates

DESKTOP_SUBSTRATE installs Sway/Waybar and writes user defaults into `/etc/skel` (not direct `/home/$user` writes) so FINALIZE user creation inherits configs safely.

AI_SUBSTRATE installs:

- system AI packages
- `uv` + `/opt/ai-venv`
- PyTorch CUDA wheels (`cu124` index)
- ML requirements bundle
- llama.cpp built with CMake + `GGML_CUDA=ON` in `/opt/llama-cpp`
- explicit CUDA arch selection via config (`LLAMA_CUDA_ARCHITECTURES`)
- AI helper scripts
- quadlets in `/etc/containers/systemd`
- Jupyter server config

## Inference Substrate

INFERENCE_SUBSTRATE performs:

- cuDNN local repo install + SHA256 verification
- Rust install via rustup
- Rust minimum version gate (`RUST_MIN_VERSION`)
- `cargo install mistralrs-cli@<version>` with configured features
- explicit compute capability via config (`MISTRAL_CUDA_COMPUTE_CAP`)
- installation to `/opt/acab/bin/mistral-rs`

## Validation (acabos-doctor)

Doctor runs 22 checks across 7 domains:

- Storage
- Boot
- Graphics
- Runtime
- Desktop
- System
- Manifest

Checks are dependency-aware and use skip semantics to avoid cascade noise.

## Finalization

FINALIZE performs:

- manifest generation via `config/manifest-template.jq`
- user creation and credential bootstrap (interactive prompt, or `ACABOS_USER_PASSWORD` in non-interactive mode)
- first-login password rotation enforcement for non-root user
- root account lock
- linger enable for user
- first-boot service installation
- MOTD and `/etc/issue` deployment
- log and manifest copy into target
- pool export
