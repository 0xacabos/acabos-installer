# Stage Reference

This file summarizes the current stage contracts implemented in `lib/stage_*.sh`.

Cross-cutting resume semantics:

- Stages marked `success` in state are eligible for probe-and-skip on resume.
- Stages marked `failed`/`in_progress` are re-run.
- `FINALIZE` probe currently returns non-zero by design, so FINALIZE re-runs on resume.

## PREFLIGHT

- Verifies required binaries and block device inventory.
- Installs interactive UI dependencies (`gum`, `fzf`) in the live environment.
- Fetches and validates NVIDIA repo keyring.
- Fetches NVIDIA Container Toolkit keyring.
- Configures host APT sources for NVIDIA and updates package indexes.
- Probe: binaries + disk inventory + keyring sanity.

## INPUT

- Prompts for target disk, pool name, hostname, username.
- Disk selection uses `fzf` live preview (partition/signature context) when interactive.
- Generates install ID and writes state file.
- Probe: required state fields exist and disk path resolves.

## DISK_SAFETY

- Reconfirms target device.
- Requires typed basename confirmation.
- Wipes partition signatures (`sgdisk --zap-all`, `wipefs -a`).
- Probe: device no longer has old signatures (or later stage already succeeded).

## ZFS_CREATE

- Partitions EFI + ZFS.
- Creates encrypted pool and datasets from `lib/topology.sh`.
- Uses fixed `ashift=12` policy for all supported drive classes.
- Creates swap zvol.
- Sets pool bootfs to `${pool}/ROOT/acabos`.
- Transitions encryption key to passphrase prompt and shreds temporary key.
- Probe: bidirectional topology + property drift + encryption checks.

## BASE_INSTALL

- Runs mmdebstrap with explicit keyring and installer hooks.
- Installs base toolchain, ZFS stack, ZED, and runtime prerequisites.
- Writes fstab including swap zvol.
- Writes keyboard config and host files.
- Runs post-bootstrap DKMS autoinstall.
- Probe: target shell and kernel image present, kernel package installed.

## BOOT_CHAIN

- Installs dracut/ZBM config and cmdline.
- Installs `/etc/default/zfs` and ZBM dracut conf.
- Installs NVIDIA modprobe/udev and sysctl tuning files.
- Generates ZBM image and validates EFI artifacts.
- Registers EFI boot entry with explicit initrd boot option (best effort).
- Installs fallback loader at `/EFI/BOOT/BOOTX64.EFI`.
- Probe: ZBM artifacts + initramfs ZFS + expected tuning files (accepts `initramfs-*` or `initramfs.img`).

## NVIDIA_BRINGUP

- Installs NVIDIA DKMS/driver/CUDA packages.
- Installs NVIDIA Container Toolkit and runtime config.
- Installs CUDA environment profile + ldconfig entries.
- Enables `nvidia-persistenced` and `nvidia-power.service`.
- Build validation: DKMS status + module file presence.
- Runtime validation: strict on physical hosts, warning in virtual.
- Probe: module files + container toolkit + CUDA env file.

## PODMAN_SUBSTRATE

- Installs Podman/buildah/skopeo/networking stack.
- Installs system container config files.
- Generates CDI spec where possible.
- Probe: `podman info` works in chroot and config file exists.

## DESKTOP_SUBSTRATE

- Installs desktop package set from `config/desktop-packages.list`.
- Installs Sway + Waybar config skeleton into `/etc/skel`.
- Installs desktop helper launch scripts (`sway-nvidia`, `start-desktop`).
- Appends ACABOS aliases into `/etc/skel/.bashrc`.
- Creates `/etc/skel` workspace and XDG directories.
- Probe: sway/waybar installed + skel config files present.

## AI_SUBSTRATE

- Installs system AI package set from `config/ai-system-packages.list`.
- Installs `uv` and creates `/opt/ai-venv`.
- Installs PyTorch from CUDA wheel index and AI Python requirements.
- Builds llama.cpp with CMake (`GGML_CUDA=ON`) under `/opt/llama-cpp` with explicit `CMAKE_CUDA_ARCHITECTURES` from config.
- Installs helper scripts (`model-manager`, `gpu-benchmark`, `ai-services`, `ai-shell`, `ai-stack`, `test-nvidia-container`).
- Installs quadlets and Jupyter config.
- Probe: ai venv + llama binary + quadlet presence.

## INFERENCE_SUBSTRATE

- Downloads and verifies cuDNN local repo installer.
- Installs cuDNN package set into chroot.
- Installs Rust toolchain and enforces minimum Rust version.
- Builds and installs `mistral-rs` to `/opt/acab/bin/mistral-rs` with explicit `CUDA_COMPUTE_CAP` from config.
- Writes model manifest and systemd unit.
- Probe: `mistral-rs` executable + cuDNN library presence.

## VALIDATION

- Bind-mounts installer into target and runs `doctor/acabos-doctor` inside chroot.
- Runs doctor in pre-finalize context (`ACABOS_DOCTOR_PRE_FINALIZE=true`), so manifest checks are warning-level until FINALIZE writes the manifest.
- Hard-fails on invariant failures with severity `fail`.

## FINALIZE

- Prompts for initial user password (or consumes `ACABOS_USER_PASSWORD` for non-interactive runs).
- Creates non-root user, sets password, forces first-login rotation, and enables linger.
- Locks root account.
- Installs first-boot service, MOTD, `/etc/issue`, sudoers policy.
- Generates install manifest from `config/manifest-template.jq`.
- Copies logs/manifest into target.
- Runs best-effort cleanup.
- Exports pool and prints post-install instructions.
